################################################################################
# Author: Tyler Nichols
# Date: 2018 /11/18
#
# Part 1: Python coding
# Provide the functions necessary to determine if a relation R over set A
# is reflexive, symmetric, transitive, and/or antisemmetric. You will only
# need to change code in this file, but can change the rels.py to add extra
# functionality if you desire. Your message returned for each property will
# list at least one necessary pair for the property to hold.
# For example, if relation ((1, 0), (0, 1)) over set (0, 1) was tested for
# the reflexive property, you could report that the (0, 0) is missing.
# (In the case of antisymmetry, you can list the offending pair as
# superfluous.)
#
# NOTE: To get credit for extra functionality in either file, you must
#       mention it in the README.txt file. If there is no mention of extra
#       functionality in the rels.py file, I reserve the option to run with
#       an original copy!
#
# Part 2: Data set
# You will provide a data set (via input file; change the file name below)
# that displays as many different combinations of relation properties as
# possible. For example, a set and relation that is not reflexive(r), not
# symmetric(s), not transitive(t), and not antisymmetric(a) would be one
# set of properties: rsta. A set and relation that is reflexive(R), is
# symmetric(S), not transitive(t), and not antisymmetric(a) would be: RSta.
# How many of the 16 possible combinations can you come up with?
# Include an example for each of the 16 possible combinations, and include
# a proof explanation in your README for each combination that is
# impossible.
#
# Your final submission will include:
# - this funcs.py file with your code in the appropriate functions
# - the rels.py file (with or without updates; you don't have to update.)
# - Your input data file (with filename in funcs.py below)
# - An output file from your run (change filename below as desired.)
# - Your README.txt file, including:
#   - Your write-up describing the 16 combinations
#   - Prooftext for each combination that you deem impossible
#   - List of bugs
#   - List of TODOs
#
################################################################################

in_fname  = "input.txt"
out_fname = "output.txt"

def is_reflexive(A, R):
  # Determine if the relation R over set A is reflexive. The return value
  # will be a two-tuple of a boolean and a string message.
  # assume result is true (e.g. R is reflexive)
  result = True
  message = "reflexive"

  #iterate over A, for each element a in A, make sure R contains (a,a).
  for a in A:
    if (a,a) not in R:
      result = False
      message = "not reflexive"
  for b in A:
      if (b,b) not in R:
          result = False
          message = "not reflexive"
  for c in A:
      if (b,b) not in R:
          result = False
          message = "not reflexive"

  return result, message


def is_symmetric(A, R):
  # Determine if the relation R over set A is symmetric. The return value
  # will be a two-tuple of a boolean and a string message.
  # assume result is true (e.g. R is symmetric)
  result = True
  message = "symmetric"

  #iterate over A, for each element (a,b) in A, make sure (b,a) exist
  for a in A:
      for b in A:
          for c in A:
              for d in A:
                 if (a,b) in R:
                     if (b,a) not in R:
                         result = False
                         message = "not symmetric"
                 if (a,c) in R:
                     if (c,a) not in R:
                         result = False
                         message = "not symmetric"
                 if (a,d) in R:
                     if (d,a) not in R:
                         result = False
                         message = "not symmetric"


  return result, message

def is_transitive(A, R):
  # Determine if the relation R over set A is transitive. The return value
  # will be a two-tuple of a boolean and a string message.
  result = True
  message = "transitive"

  #iterate over A, for each element (a,b) and (b,c) in A, make sure R contains (a,c)
  for a in A:
      for b in A:
          for c in A:
              if (a,b) in R:
                  if (b,c) in R:
                     if (a,c) not in R:

                        result = False
                        message = "not transitive"
  return result, message


def is_antisymmetric(A, R):
  # Determine if the relation R over set A is antisymmetric. The return value
  # will be a two-tuple of a boolean and a string message.
  result = True
  message = "antisymmetric"
  #iterate over A, for each element (a,b) and (b,a) a=b or if (a,b) exist or (b,a) exist but not together then a =/= b
  for a in A:
      for b in A:
          if (a,b) in R:
              if (b,a) in R:
                  if a != b in R:
                   result = False
                   message = "not antisymmetric"
              if (b,a) not in R:
                  if a == b in R:
                      result = False
                      message = "not antisymmetric"
          if (b,a) in R:
              if (a,b) not in R:
                  if a == b in R:
                      result = False
                      message = "not antisymmetric"
  return result, message
