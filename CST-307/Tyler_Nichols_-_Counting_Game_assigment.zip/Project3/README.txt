README.txt

~~~Extra Feature~~~
My extra feature was that the robots could fight one another and determine who is superior model.
In all actuality, the robot fight is simply a way of seeing what might be the most optimal way to perform the game as you can see the computer do it constantly against itself.

~~~Algorithm~~~

My program uses multiple if/else statements and a single while loop to maintain the game for either the player vs player, or the computer vs itself
The most difficult part of the program was to ensure that the computers inputs weren't the same responses again and again but different numbers each time the game was attempted.

~~~Improvements~~~

Two improvements I could implement are the use of the if/else statements so that program could be coded using less lines, thus making it faster
Another improvement would be to allow multiple users and for the user to create multiple computer enemies against him to play against with friends.


